
## Muito bem-vinda e muito bem-vindo ao Jogo da Forca, com o foco no assunto "Dia das Mães ##


## Apresentação do jogo:

** Para deixar com uma cara de site, publiquei o mesmo na Vercel, podendo acessar neste link:***************************

** Na abertura da página, automaticamente será aberto um pop-up, infromando para iniciar o jogo e "chutar uma letra".  

** O jogo é composto por seis palavras, relacionadas às nossas mães e coisas que recebemos ao longo de nossas vidas. As palavras são sorteadas aleatoriamente a cada partida.

** Cada partida é composta por seis tentativas. Em cada erro, aparecerá uma imagem do tradicional jogo da forca, e atualizada, conforme o número de tentativas erradas forem aumentando. Totalizando seis erros, aparecerá uma mensagem, informando de sua derrota. 

** Para jogar, há um teclado disponibilizado no programa, podendo utilizar apenas o mouse. Ainda, para facilitar o desenvolvimento da partida, a cada chute de letra:


     => Em caso de acerto, o identificador completará todas as células que contenham a letra correspondente;

     => A tecla da letra, independentemente de correta ou errada, ao ser clicada será automaticamente desabilitada, sendo destacada nas cores de tecla: em fundo roxo e letra na cor branca. Em caso de erro, a tecla desabilitada ajudará para impedir um novo erro.


** Abaixo do teclado, há uma frase dando uma dica para acerto da palavra sorteada.

** Para  reiniciar a partida, poderá clicar na última tecla da direita, da terceira fileira, com o simbolo de corações. 



